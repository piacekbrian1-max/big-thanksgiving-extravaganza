Big Thanksgiving Extravaganza website

Open index.html in a browser to view the trip website.
For online hosting, upload the contents of this folder to a static hosting service.
